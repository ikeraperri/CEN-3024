//Author Name: Iker Aperribay
//Date: 01/21/20
//Program Name: Aperribay_DroneObject
//Purpose: creating a drone object

public class Aperribay_DroneObject 
{
	int locx;
	int locy;
	int locz;
	int orientationNumber;
	String orientation;

	public Aperribay_DroneObject (int locx, int locy, int locz, int orientationNumber, String orientation) 
	{
		this.locx = locx;
		this.locy = locy;
		this.locz = locz;
		this.orientationNumber = orientationNumber;
		this.orientation = orientation;
	}
	
	@Override
	public String toString() {
		return   "Student_Drone [x_pos = "+locx+", y_pos = "+locy+", z_pos = "+locz+", orientation = "+orientation+"]";
	}
}
