//Author Name: Iker Aperribay
//Date: 01/21/20
//Program Name: Aperribay_Drone
//Purpose: Simulation using UI, drone movement in x,y,z location and orientation

import java.util.Scanner;

public class Aperribay_Drone 
{

	public static void main(String[] args) 
	{
		int locx = 0;
		int locy = 0;
		int locz = 0;
		int orientationNumber = 100;
		String orientation = "";
		
		Aperribay_DroneObject Student_Drone = new Aperribay_DroneObject(locx, locy, locz, orientationNumber, orientation);
		
		Scanner input = new Scanner(System.in);
		
		for(int i=1; i<=2; i++)
		{
			System.out.println("Which direction would you like to move the drone?");
			System.out.println("1 - Move up");
			System.out.println("2 - Move down");
			System.out.println("3 - Move forward");
			System.out.println("4 - Move back");
			System.out.println("5 - Turn left");
			System.out.println("6 - Turn right");
			System.out.println("7 - Display position");
			System.out.println("8 - Exit navigation");
			
			int number = input.nextInt();
			
			if (Student_Drone.orientationNumber % 4 ==0)
			{
				Student_Drone.orientation = "North";
			}
			if (Student_Drone.orientationNumber % 4 ==1)
			{
				Student_Drone.orientation = "East";
			}
			if (Student_Drone.orientationNumber % 4 ==2)
			{
				Student_Drone.orientation = "South";
			}
			if (Student_Drone.orientationNumber % 4 ==3)
			{
				Student_Drone.orientation = "West";
			}
			
			ControlDrone(Student_Drone, number);
			
			if(number == 8)
			{
				i = 4;
				System.out.println("Navigation Complete");
			}
			i--;
		}
		input.close();
		
	}
	
	public static Aperribay_DroneObject ControlDrone(Aperribay_DroneObject Student_Drone, int input)
	{
		if(Student_Drone.orientation == "North")
		{
			switch(input)
			{ 
				case 1: Student_Drone.locz++;
					break;
				case 2: Student_Drone.locz--;
					break;
				case 3: Student_Drone.locy++;
					break;
				case 4: Student_Drone.locy--;
					break;
				case 5: Student_Drone.orientationNumber--;
					break;
				case 6: Student_Drone.orientationNumber++;
					break;
				case 7: DisplayLocation(Student_Drone);
					break;
				case 8: 
					break;
			}
		}
		
		if(Student_Drone.orientation == "West")
		{
			switch(input)
			{ 
				case 1: Student_Drone.locz++;
					break;
				case 2: Student_Drone.locz--;
					break;
				case 3: Student_Drone.locx--;
					break;
				case 4: Student_Drone.locx++;
					break;
				case 5: Student_Drone.orientationNumber--;
					break;
				case 6: Student_Drone.orientationNumber++;
					break;
				case 7: DisplayLocation(Student_Drone);
					break;
				case 8: 
					break;
			}
		}
		
		if(Student_Drone.orientation == "South")
		{
			switch(input)
			{ 
				case 1: Student_Drone.locz++;
					break;
				case 2: Student_Drone.locz--;
					break;
				case 3: Student_Drone.locy--;
					break;
				case 4: Student_Drone.locy++;
					break;
				case 5: Student_Drone.orientationNumber--;
					break;
				case 6: Student_Drone.orientationNumber++;
					break;
				case 7: DisplayLocation(Student_Drone);
					break;
				case 8: 
					break;
			}
		}
		
		if(Student_Drone.orientation == "East")
		{
			switch(input)
			{ 
				case 1: Student_Drone.locz++;
					break;
				case 2: Student_Drone.locz--;
					break;
				case 3: Student_Drone.locx++;
					break;
				case 4: Student_Drone.locx--;
					break;
				case 5: Student_Drone.orientationNumber--;
					break;
				case 6: Student_Drone.orientationNumber++;
					break;
				case 7: DisplayLocation(Student_Drone);
					break;
				case 8: 
					break;
			}
		}
		return Student_Drone;
	}
	
	public static void DisplayLocation(Aperribay_DroneObject Student_Drone)
	{
		System.out.println(Student_Drone);
	}

}
